package com.aluguel.controller;

import com.aluguel.dao.AluguelDAO;
import com.aluguel.dao.VeiculoDAO;
import com.aluguel.dao.ClienteDAO;
import com.aluguel.model.Aluguel;
import com.aluguel.model.Veiculo;
import com.aluguel.model.Cliente;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

@ManagedBean
@ViewScoped
public class AluguelBean implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Aluguel aluguel = new Aluguel();
    private List<Aluguel> alugueis;
    private List<Aluguel> alugueisAtrasados;
    private AluguelDAO aluguelDAO = new AluguelDAO();
    private VeiculoDAO veiculoDAO = new VeiculoDAO();
    private ClienteDAO clienteDAO = new ClienteDAO();
    
    private Integer veiculoSelecionado;
    private Integer clienteSelecionado;
    
    public void salvar() {
        try {
            // Validar se veículo e cliente foram selecionados
            if (veiculoSelecionado == null) {
                addMessage("Selecione um veículo!", FacesMessage.SEVERITY_WARN);
                return;
            }
            if (clienteSelecionado == null) {
                addMessage("Selecione um cliente!", FacesMessage.SEVERITY_WARN);
                return;
            }
            
            // Buscar veículo e cliente
            Veiculo veiculo = veiculoDAO.buscarPorNumero(veiculoSelecionado);
            Cliente cliente = clienteDAO.buscarPorId(clienteSelecionado);
            
            if (veiculo == null) {
                addMessage("Veículo não encontrado!", FacesMessage.SEVERITY_ERROR);
                return;
            }
            if (cliente == null) {
                addMessage("Cliente não encontrado!", FacesMessage.SEVERITY_ERROR);
                return;
            }
            
            // Verificar disponibilidade do veículo (apenas para novos aluguéis)
            if (aluguel.getIdAluguel() == null && !veiculoDAO.verificarDisponibilidade(veiculoSelecionado)) {
                addMessage("Este veículo já está alugado e não foi entregue!", FacesMessage.SEVERITY_WARN);
                return;
            }
            
            aluguel.setVeiculo(veiculo);
            aluguel.setCliente(cliente);
            
            if (aluguel.getIdAluguel() == null) {
                aluguelDAO.inserir(aluguel);
                addMessage("Aluguel cadastrado com sucesso!", FacesMessage.SEVERITY_INFO);
            } else {
                aluguelDAO.atualizar(aluguel);
                addMessage("Aluguel atualizado com sucesso!", FacesMessage.SEVERITY_INFO);
            }
            limpar();
            alugueis = null;
            alugueisAtrasados = null;
        } catch (SQLException e) {
            addMessage("Erro ao salvar aluguel: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void excluir(Aluguel aluguel) {
        try {
            aluguelDAO.excluir(aluguel.getIdAluguel());
            addMessage("Aluguel excluído com sucesso!", FacesMessage.SEVERITY_INFO);
            alugueis = null;
            alugueisAtrasados = null;
        } catch (SQLException e) {
            addMessage("Erro ao excluir aluguel: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void editar(Aluguel aluguel) {
        // Cria uma cópia do objeto para evitar problemas de referência
        this.aluguel = new Aluguel();
        this.aluguel.setIdAluguel(aluguel.getIdAluguel());
        this.aluguel.setDataAluguel(aluguel.getDataAluguel());
        this.aluguel.setDataEntrega(aluguel.getDataEntrega());
        this.aluguel.setEntregue(aluguel.isEntregue());
        this.aluguel.setObservacao(aluguel.getObservacao());
        this.aluguel.setValorPago(aluguel.getValorPago());
        this.aluguel.setDataCadastro(aluguel.getDataCadastro());
        
        // Define os IDs selecionados para os dropdowns
        if (aluguel.getVeiculo() != null) {
            this.veiculoSelecionado = aluguel.getVeiculo().getNumero();
            this.aluguel.setVeiculo(aluguel.getVeiculo());
        }
        if (aluguel.getCliente() != null) {
            this.clienteSelecionado = aluguel.getCliente().getId();
            this.aluguel.setCliente(aluguel.getCliente());
        }
    }
    
    public void marcarComoEntregue(Aluguel aluguel) {
        try {
            aluguel.setEntregue(true);
            aluguelDAO.atualizar(aluguel);
            addMessage("Veículo marcado como entregue!", FacesMessage.SEVERITY_INFO);
            alugueis = null;
            alugueisAtrasados = null;
        } catch (SQLException e) {
            addMessage("Erro ao atualizar aluguel: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void limpar() {
        this.aluguel = new Aluguel();
        this.veiculoSelecionado = null;
        this.clienteSelecionado = null;
    }
    
    public List<Aluguel> getAlugueis() {
        if (alugueis == null) {
            try {
                alugueis = aluguelDAO.listarTodos();
            } catch (SQLException e) {
                addMessage("Erro ao listar aluguéis: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
            }
        }
        return alugueis;
    }
    
    public List<Aluguel> getAlugueisAtrasados() {
        if (alugueisAtrasados == null) {
            try {
                alugueisAtrasados = aluguelDAO.listarNaoEntregues();
            } catch (SQLException e) {
                addMessage("Erro ao listar aluguéis atrasados: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
            }
        }
        return alugueisAtrasados;
    }
    
    public List<Veiculo> getVeiculosDisponiveis() {
        try {
            return veiculoDAO.listarTodos();
        } catch (SQLException e) {
            addMessage("Erro ao listar veículos: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
            return null;
        }
    }
    
    public List<Cliente> getClientesDisponiveis() {
        try {
            return clienteDAO.listarTodos();
        } catch (SQLException e) {
            addMessage("Erro ao listar clientes: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
            return null;
        }
    }
    
    private void addMessage(String mensagem, FacesMessage.Severity severity) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, mensagem, ""));
    }
    
    public Aluguel getAluguel() { return aluguel; }
    public void setAluguel(Aluguel aluguel) { this.aluguel = aluguel; }
    public Integer getVeiculoSelecionado() { return veiculoSelecionado; }
    public void setVeiculoSelecionado(Integer veiculoSelecionado) { this.veiculoSelecionado = veiculoSelecionado; }
    public Integer getClienteSelecionado() { return clienteSelecionado; }
    public void setClienteSelecionado(Integer clienteSelecionado) { this.clienteSelecionado = clienteSelecionado; }
}