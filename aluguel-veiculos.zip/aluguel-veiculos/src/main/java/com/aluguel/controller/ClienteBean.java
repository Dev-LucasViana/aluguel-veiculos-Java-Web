package com.aluguel.controller;

import com.aluguel.dao.ClienteDAO;
import com.aluguel.model.Cliente;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

@ManagedBean
@ViewScoped
public class ClienteBean implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Cliente cliente = new Cliente();
    private List<Cliente> clientes;
    private ClienteDAO clienteDAO = new ClienteDAO();
    
    public void salvar() {
        try {
            if (cliente.getId() == null) {
                clienteDAO.inserir(cliente);
                addMessage("Cliente cadastrado com sucesso!", FacesMessage.SEVERITY_INFO);
            } else {
                clienteDAO.atualizar(cliente);
                addMessage("Cliente atualizado com sucesso!", FacesMessage.SEVERITY_INFO);
            }
            limpar();
            clientes = null;
        } catch (SQLException e) {
            addMessage("Erro ao salvar cliente: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void excluir(Cliente cliente) {
        try {
            clienteDAO.excluir(cliente.getId());
            addMessage("Cliente excluído com sucesso!", FacesMessage.SEVERITY_INFO);
            clientes = null;
        } catch (SQLException e) {
            addMessage("Erro ao excluir cliente: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void editar(Cliente cliente) {
        // Cria uma cópia do objeto para evitar problemas de referência
        this.cliente = new Cliente();
        this.cliente.setId(cliente.getId());
        this.cliente.setNomeCliente(cliente.getNomeCliente());
        this.cliente.setEndereco(cliente.getEndereco());
        this.cliente.setUf(cliente.getUf());
        this.cliente.setTelefone(cliente.getTelefone());
        this.cliente.setCpf(cliente.getCpf());
        this.cliente.setEmail(cliente.getEmail());
        this.cliente.setAtivo(cliente.isAtivo());
        this.cliente.setDataCadastro(cliente.getDataCadastro());
    }
    
    public void limpar() {
        this.cliente = new Cliente();
    }
    
    public List<Cliente> getClientes() {
        if (clientes == null) {
            try {
                clientes = clienteDAO.listarTodos();
            } catch (SQLException e) {
                addMessage("Erro ao listar clientes: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
            }
        }
        return clientes;
    }
    
    private void addMessage(String mensagem, FacesMessage.Severity severity) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, mensagem, ""));
    }
    
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
}