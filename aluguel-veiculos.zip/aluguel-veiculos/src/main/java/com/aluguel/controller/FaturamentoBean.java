package com.aluguel.controller;

import com.aluguel.dao.AluguelDAO;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

@ManagedBean
@ViewScoped
public class FaturamentoBean implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Date dataInicio;
    private Date dataFim;
    private Double faturamentoTotal;
    private AluguelDAO aluguelDAO = new AluguelDAO();
    
    public void consultar() {
        try {
            if (dataInicio == null || dataFim == null) {
                addMessage("Informe o período completo!", FacesMessage.SEVERITY_WARN);
                return;
            }
            
            if (dataInicio.after(dataFim)) {
                addMessage("A data inicial não pode ser maior que a data final!", FacesMessage.SEVERITY_WARN);
                return;
            }
            
            faturamentoTotal = aluguelDAO.calcularFaturamento(dataInicio, dataFim);
            addMessage("Consulta realizada com sucesso!", FacesMessage.SEVERITY_INFO);
        } catch (SQLException e) {
            addMessage("Erro ao consultar faturamento: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void limpar() {
        this.dataInicio = null;
        this.dataFim = null;
        this.faturamentoTotal = null;
    }
    
    private void addMessage(String mensagem, FacesMessage.Severity severity) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, mensagem, ""));
    }
    
    public Date getDataInicio() { return dataInicio; }
    public void setDataInicio(Date dataInicio) { this.dataInicio = dataInicio; }
    
    public Date getDataFim() { return dataFim; }
    public void setDataFim(Date dataFim) { this.dataFim = dataFim; }
    
    public Double getFaturamentoTotal() { return faturamentoTotal; }
    public void setFaturamentoTotal(Double faturamentoTotal) { this.faturamentoTotal = faturamentoTotal; }
}