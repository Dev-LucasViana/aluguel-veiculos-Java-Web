package com.aluguel.controller;

import com.aluguel.dao.UsuarioDAO;
import com.aluguel.model.Usuario;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.sql.SQLException;

@ManagedBean
@SessionScoped
public class LoginBean implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String login;
    private String senha;
    private Usuario usuarioLogado;
    private UsuarioDAO usuarioDAO = new UsuarioDAO();
    
    public String efetuarLogin() {
        try {
            Usuario usuario = usuarioDAO.buscarPorLogin(login);
            
            if (usuario != null && usuario.getSenha().equals(senha)) {
                usuarioLogado = usuario;
                addMessage("Bem-vindo, " + usuario.getNome() + "!", FacesMessage.SEVERITY_INFO);
                return "index?faces-redirect=true";
            } else {
                addMessage("Login ou senha inválidos!", FacesMessage.SEVERITY_ERROR);
                return null;
            }
        } catch (SQLException e) {
            addMessage("Erro ao efetuar login: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
            return null;
        }
    }
    
    public String efetuarLogout() {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "login?faces-redirect=true";
    }
    
    public boolean isLogado() {
        return usuarioLogado != null;
    }
    
    private void addMessage(String mensagem, FacesMessage.Severity severity) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, mensagem, ""));
    }
    
    // Getters e Setters
    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }
    
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    
    public Usuario getUsuarioLogado() { return usuarioLogado; }
    public void setUsuarioLogado(Usuario usuarioLogado) { this.usuarioLogado = usuarioLogado; }
}