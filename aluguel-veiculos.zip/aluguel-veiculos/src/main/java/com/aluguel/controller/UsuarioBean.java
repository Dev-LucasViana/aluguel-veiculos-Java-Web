package com.aluguel.controller;

import com.aluguel.dao.UsuarioDAO;
import com.aluguel.model.Usuario;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

@ManagedBean
@ViewScoped
public class UsuarioBean implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Usuario usuario = new Usuario();
    private List<Usuario> usuarios;
    private UsuarioDAO usuarioDAO = new UsuarioDAO();
    
    public void salvar() {
        try {
            if (usuario.getId() == null) {
                usuarioDAO.inserir(usuario);
                addMessage("Usuário cadastrado com sucesso!", FacesMessage.SEVERITY_INFO);
            } else {
                usuarioDAO.atualizar(usuario);
                addMessage("Usuário atualizado com sucesso!", FacesMessage.SEVERITY_INFO);
            }
            limpar();
            usuarios = null;
        } catch (SQLException e) {
            addMessage("Erro ao salvar usuário: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void excluir(Usuario usuario) {
        try {
            usuarioDAO.excluir(usuario.getId());
            addMessage("Usuário excluído com sucesso!", FacesMessage.SEVERITY_INFO);
            usuarios = null;
        } catch (SQLException e) {
            addMessage("Erro ao excluir usuário: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void editar(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public void limpar() {
        this.usuario = new Usuario();
    }
    
    public List<Usuario> getUsuarios() {
        if (usuarios == null) {
            try {
                usuarios = usuarioDAO.listarTodos();
            } catch (SQLException e) {
                addMessage("Erro ao listar usuários: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
            }
        }
        return usuarios;
    }
    
    private void addMessage(String mensagem, FacesMessage.Severity severity) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, mensagem, ""));
    }
    
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
}