package com.aluguel.controller;

import com.aluguel.dao.VeiculoDAO;
import com.aluguel.model.Veiculo;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

@ManagedBean
@ViewScoped
public class VeiculoBean implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Veiculo veiculo = new Veiculo();
    private List<Veiculo> veiculos;
    private VeiculoDAO veiculoDAO = new VeiculoDAO();
    
    public void salvar() {
        try {
            if (veiculo.getNumero() == null) {
                veiculoDAO.inserir(veiculo);
                addMessage("Veículo cadastrado com sucesso!", FacesMessage.SEVERITY_INFO);
            } else {
                veiculoDAO.atualizar(veiculo);
                addMessage("Veículo atualizado com sucesso!", FacesMessage.SEVERITY_INFO);
            }
            limpar();
            veiculos = null;
        } catch (SQLException e) {
            addMessage("Erro ao salvar veículo: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void excluir(Veiculo veiculo) {
        try {
            if (!veiculoDAO.verificarDisponibilidade(veiculo.getNumero())) {
                addMessage("Não é possível excluir um veículo que está alugado!", FacesMessage.SEVERITY_WARN);
                return;
            }
            veiculoDAO.excluir(veiculo.getNumero());
            addMessage("Veículo excluído com sucesso!", FacesMessage.SEVERITY_INFO);
            veiculos = null;
        } catch (SQLException e) {
            addMessage("Erro ao excluir veículo: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void editar(Veiculo veiculo) {
        // Cria uma cópia do objeto para evitar problemas de referência
        this.veiculo = new Veiculo();
        this.veiculo.setNumero(veiculo.getNumero());
        this.veiculo.setPlaca(veiculo.getPlaca());
        this.veiculo.setFabricante(veiculo.getFabricante());
        this.veiculo.setModelo(veiculo.getModelo());
        this.veiculo.setAnoModelo(veiculo.getAnoModelo());
        this.veiculo.setQtdPortas(veiculo.getQtdPortas());
        this.veiculo.setAcessorios(veiculo.getAcessorios());
        this.veiculo.setAtivo(veiculo.isAtivo());
        this.veiculo.setDataCadastro(veiculo.getDataCadastro());
    }
    
    public void limpar() {
        this.veiculo = new Veiculo();
    }
    
    public List<Veiculo> getVeiculos() {
        if (veiculos == null) {
            try {
                veiculos = veiculoDAO.listarTodos();
            } catch (SQLException e) {
                addMessage("Erro ao listar veículos: " + e.getMessage(), FacesMessage.SEVERITY_ERROR);
            }
        }
        return veiculos;
    }
    
    private void addMessage(String mensagem, FacesMessage.Severity severity) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, mensagem, ""));
    }
    
    public Veiculo getVeiculo() { return veiculo; }
    public void setVeiculo(Veiculo veiculo) { this.veiculo = veiculo; }
}