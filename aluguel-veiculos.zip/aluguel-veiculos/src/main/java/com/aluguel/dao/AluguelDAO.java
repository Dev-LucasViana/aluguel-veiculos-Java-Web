package com.aluguel.dao;

import com.aluguel.model.Aluguel;
import com.aluguel.model.Cliente;
import com.aluguel.model.Veiculo;
import com.aluguel.util.DatabaseConfig;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AluguelDAO {
    private VeiculoDAO veiculoDAO = new VeiculoDAO();
    private ClienteDAO clienteDAO = new ClienteDAO();
    
    public void inserir(Aluguel aluguel) throws SQLException {
        String sql = "INSERT INTO aluguel (numero_veiculo, data_aluguel, data_entrega, " +
                     "id_cliente, entregue, observacao, valor_pago) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, aluguel.getVeiculo().getNumero());
            stmt.setDate(2, new java.sql.Date(aluguel.getDataAluguel().getTime()));
            stmt.setDate(3, new java.sql.Date(aluguel.getDataEntrega().getTime()));
            stmt.setInt(4, aluguel.getCliente().getId());
            stmt.setBoolean(5, aluguel.isEntregue());
            stmt.setString(6, aluguel.getObservacao());
            stmt.setDouble(7, aluguel.getValorPago());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                aluguel.setIdAluguel(rs.getInt(1));
            }
        }
    }
    
    public void atualizar(Aluguel aluguel) throws SQLException {
        String sql = "UPDATE aluguel SET numero_veiculo = ?, data_aluguel = ?, data_entrega = ?, " +
                     "id_cliente = ?, entregue = ?, observacao = ?, valor_pago = ? WHERE id_aluguel = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, aluguel.getVeiculo().getNumero());
            stmt.setDate(2, new java.sql.Date(aluguel.getDataAluguel().getTime()));
            stmt.setDate(3, new java.sql.Date(aluguel.getDataEntrega().getTime()));
            stmt.setInt(4, aluguel.getCliente().getId());
            stmt.setBoolean(5, aluguel.isEntregue());
            stmt.setString(6, aluguel.getObservacao());
            stmt.setDouble(7, aluguel.getValorPago());
            stmt.setInt(8, aluguel.getIdAluguel());
            
            stmt.executeUpdate();
        }
    }
    
    public void excluir(Integer id) throws SQLException {
        String sql = "DELETE FROM aluguel WHERE id_aluguel = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    public Aluguel buscarPorId(Integer id) throws SQLException {
        String sql = "SELECT * FROM aluguel WHERE id_aluguel = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extrairAluguel(rs);
            }
        }
        return null;
    }
    
    public List<Aluguel> listarTodos() throws SQLException {
        String sql = "SELECT * FROM aluguel ORDER BY data_aluguel DESC";
        List<Aluguel> lista = new ArrayList<>();
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                lista.add(extrairAluguel(rs));
            }
        }
        return lista;
    }
    
    public List<Aluguel> listarNaoEntregues() throws SQLException {
        String sql = "SELECT * FROM aluguel WHERE entregue = FALSE AND data_entrega < CURDATE() " +
                     "ORDER BY data_entrega";
        List<Aluguel> lista = new ArrayList<>();
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                lista.add(extrairAluguel(rs));
            }
        }
        return lista;
    }
    
    public Double calcularFaturamento(Date dataInicio, Date dataFim) throws SQLException {
        String sql = "SELECT COALESCE(SUM(valor_pago), 0) FROM aluguel " +
                     "WHERE data_aluguel BETWEEN ? AND ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setDate(1, new java.sql.Date(dataInicio.getTime()));
            stmt.setDate(2, new java.sql.Date(dataFim.getTime()));
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return 0.0;
    }
    
    private Aluguel extrairAluguel(ResultSet rs) throws SQLException {
        Aluguel aluguel = new Aluguel();
        aluguel.setIdAluguel(rs.getInt("id_aluguel"));
        aluguel.setVeiculo(veiculoDAO.buscarPorNumero(rs.getInt("numero_veiculo")));
        aluguel.setDataAluguel(rs.getDate("data_aluguel"));
        aluguel.setDataEntrega(rs.getDate("data_entrega"));
        aluguel.setCliente(clienteDAO.buscarPorId(rs.getInt("id_cliente")));
        aluguel.setEntregue(rs.getBoolean("entregue"));
        aluguel.setObservacao(rs.getString("observacao"));
        aluguel.setValorPago(rs.getDouble("valor_pago"));
        aluguel.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return aluguel;
    }
}