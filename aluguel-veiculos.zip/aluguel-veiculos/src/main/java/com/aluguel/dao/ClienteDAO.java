package com.aluguel.dao;

import com.aluguel.model.Cliente;
import com.aluguel.util.DatabaseConfig;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
    
    public void inserir(Cliente cliente) throws SQLException {
        String sql = "INSERT INTO cliente (nome_cliente, endereco, uf, telefone, cpf, email) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, cliente.getNomeCliente());
            stmt.setString(2, cliente.getEndereco());
            stmt.setString(3, cliente.getUf());
            stmt.setString(4, cliente.getTelefone());
            stmt.setString(5, cliente.getCpf());
            stmt.setString(6, cliente.getEmail());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                cliente.setId(rs.getInt(1));
            }
        }
    }
    
    public void atualizar(Cliente cliente) throws SQLException {
        String sql = "UPDATE cliente SET nome_cliente = ?, endereco = ?, uf = ?, " +
                     "telefone = ?, cpf = ?, email = ? WHERE id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cliente.getNomeCliente());
            stmt.setString(2, cliente.getEndereco());
            stmt.setString(3, cliente.getUf());
            stmt.setString(4, cliente.getTelefone());
            stmt.setString(5, cliente.getCpf());
            stmt.setString(6, cliente.getEmail());
            stmt.setInt(7, cliente.getId());
            
            stmt.executeUpdate();
        }
    }
    
    public void excluir(Integer id) throws SQLException {
        String sql = "UPDATE cliente SET ativo = FALSE WHERE id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    public Cliente buscarPorId(Integer id) throws SQLException {
        String sql = "SELECT * FROM cliente WHERE id = ? AND ativo = TRUE";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extrairCliente(rs);
            }
        }
        return null;
    }
    
    public List<Cliente> listarTodos() throws SQLException {
        String sql = "SELECT * FROM cliente WHERE ativo = TRUE ORDER BY nome_cliente";
        List<Cliente> lista = new ArrayList<>();
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                lista.add(extrairCliente(rs));
            }
        }
        return lista;
    }
    
    public Cliente buscarPorCpf(String cpf) throws SQLException {
        String sql = "SELECT * FROM cliente WHERE cpf = ? AND ativo = TRUE";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extrairCliente(rs);
            }
        }
        return null;
    }
    
    private Cliente extrairCliente(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente();
        cliente.setId(rs.getInt("id"));
        cliente.setNomeCliente(rs.getString("nome_cliente"));
        cliente.setEndereco(rs.getString("endereco"));
        cliente.setUf(rs.getString("uf"));
        cliente.setTelefone(rs.getString("telefone"));
        cliente.setCpf(rs.getString("cpf"));
        cliente.setEmail(rs.getString("email"));
        cliente.setAtivo(rs.getBoolean("ativo"));
        cliente.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return cliente;
    }
}