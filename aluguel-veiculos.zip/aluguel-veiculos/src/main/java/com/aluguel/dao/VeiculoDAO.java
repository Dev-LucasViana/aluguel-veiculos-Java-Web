package com.aluguel.dao;

import com.aluguel.model.Veiculo;
import com.aluguel.util.DatabaseConfig;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VeiculoDAO {
    
    public void inserir(Veiculo veiculo) throws SQLException {
        String sql = "INSERT INTO veiculo (placa, fabricante, modelo, ano_modelo, qtd_portas, acessorios) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, veiculo.getPlaca());
            stmt.setString(2, veiculo.getFabricante());
            stmt.setString(3, veiculo.getModelo());
            stmt.setInt(4, veiculo.getAnoModelo());
            stmt.setInt(5, veiculo.getQtdPortas());
            stmt.setString(6, veiculo.getAcessorios());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                veiculo.setNumero(rs.getInt(1));
            }
        }
    }
    
    public void atualizar(Veiculo veiculo) throws SQLException {
        String sql = "UPDATE veiculo SET placa = ?, fabricante = ?, modelo = ?, " +
                     "ano_modelo = ?, qtd_portas = ?, acessorios = ? WHERE numero = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, veiculo.getPlaca());
            stmt.setString(2, veiculo.getFabricante());
            stmt.setString(3, veiculo.getModelo());
            stmt.setInt(4, veiculo.getAnoModelo());
            stmt.setInt(5, veiculo.getQtdPortas());
            stmt.setString(6, veiculo.getAcessorios());
            stmt.setInt(7, veiculo.getNumero());
            
            stmt.executeUpdate();
        }
    }
    
    public void excluir(Integer numero) throws SQLException {
        String sql = "UPDATE veiculo SET ativo = FALSE WHERE numero = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, numero);
            stmt.executeUpdate();
        }
    }
    
    public Veiculo buscarPorNumero(Integer numero) throws SQLException {
        String sql = "SELECT * FROM veiculo WHERE numero = ? AND ativo = TRUE";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, numero);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extrairVeiculo(rs);
            }
        }
        return null;
    }
    
    public List<Veiculo> listarTodos() throws SQLException {
        String sql = "SELECT * FROM veiculo WHERE ativo = TRUE ORDER BY fabricante, modelo";
        List<Veiculo> lista = new ArrayList<>();
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                lista.add(extrairVeiculo(rs));
            }
        }
        return lista;
    }
    
    public boolean verificarDisponibilidade(Integer numero) throws SQLException {
        String sql = "SELECT COUNT(*) FROM aluguel WHERE numero_veiculo = ? AND entregue = FALSE";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, numero);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) == 0;
            }
        }
        return false;
    }
    
    private Veiculo extrairVeiculo(ResultSet rs) throws SQLException {
        Veiculo veiculo = new Veiculo();
        veiculo.setNumero(rs.getInt("numero"));
        veiculo.setPlaca(rs.getString("placa"));
        veiculo.setFabricante(rs.getString("fabricante"));
        veiculo.setModelo(rs.getString("modelo"));
        veiculo.setAnoModelo(rs.getInt("ano_modelo"));
        veiculo.setQtdPortas(rs.getInt("qtd_portas"));
        veiculo.setAcessorios(rs.getString("acessorios"));
        veiculo.setAtivo(rs.getBoolean("ativo"));
        veiculo.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return veiculo;
    }
}