package com.aluguel.filter;

import com.aluguel.controller.LoginBean;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(urlPatterns = {"*.xhtml"})
public class LoginFilter implements Filter {
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);
        
        String requestURI = httpRequest.getRequestURI();
        
        // Permite acesso à página de login e recursos
        if (requestURI.contains("login.xhtml") || 
            requestURI.contains("/javax.faces.resource/")) {
            chain.doFilter(request, response);
            return;
        }
        
        // Verifica se usuário está logado
        LoginBean loginBean = null;
        if (session != null) {
            loginBean = (LoginBean) session.getAttribute("loginBean");
        }
        
        if (loginBean != null && loginBean.isLogado()) {
            chain.doFilter(request, response);
        } else {
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.xhtml");
        }
    }
    
    @Override
    public void destroy() {
    }
}