package com.aluguel.model;

import java.io.Serializable;
import java.util.Date;

public class Aluguel implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Integer idAluguel;
    private Veiculo veiculo;
    private Date dataAluguel;
    private Date dataEntrega;
    private Cliente cliente;
    private boolean entregue;
    private String observacao;
    private Double valorPago;
    private Date dataCadastro;
    
    public Aluguel() {
        this.entregue = false;
    }
    
    public Aluguel(Veiculo veiculo, Date dataAluguel, Date dataEntrega, Cliente cliente, 
                   String observacao, Double valorPago) {
        this.veiculo = veiculo;
        this.dataAluguel = dataAluguel;
        this.dataEntrega = dataEntrega;
        this.cliente = cliente;
        this.observacao = observacao;
        this.valorPago = valorPago;
        this.entregue = false;
    }
    
    // Getters e Setters
    public Integer getIdAluguel() { return idAluguel; }
    public void setIdAluguel(Integer idAluguel) { this.idAluguel = idAluguel; }
    
    public Veiculo getVeiculo() { return veiculo; }
    public void setVeiculo(Veiculo veiculo) { this.veiculo = veiculo; }
    
    public Date getDataAluguel() { return dataAluguel; }
    public void setDataAluguel(Date dataAluguel) { this.dataAluguel = dataAluguel; }
    
    public Date getDataEntrega() { return dataEntrega; }
    public void setDataEntrega(Date dataEntrega) { this.dataEntrega = dataEntrega; }
    
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    
    public boolean isEntregue() { return entregue; }
    public void setEntregue(boolean entregue) { this.entregue = entregue; }
    
    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }
    
    public Double getValorPago() { return valorPago; }
    public void setValorPago(Double valorPago) { this.valorPago = valorPago; }
    
    public Date getDataCadastro() { return dataCadastro; }
    public void setDataCadastro(Date dataCadastro) { this.dataCadastro = dataCadastro; }
    
    public boolean isAtrasado() {
        if (!entregue && dataEntrega != null) {
            return new Date().after(dataEntrega);
        }
        return false;
    }
}