package com.aluguel.model;

import java.io.Serializable;
import java.util.Date;

public class Veiculo implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Integer numero;
    private String placa;
    private String fabricante;
    private String modelo;
    private Integer anoModelo;
    private Integer qtdPortas;
    private String acessorios;
    private boolean ativo;
    private Date dataCadastro;
    
    public Veiculo() {
        this.ativo = true;
    }
    
    public Veiculo(String placa, String fabricante, String modelo, Integer anoModelo, 
                   Integer qtdPortas, String acessorios) {
        this.placa = placa;
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.anoModelo = anoModelo;
        this.qtdPortas = qtdPortas;
        this.acessorios = acessorios;
        this.ativo = true;
    }
    
    // Getters e Setters
    public Integer getNumero() { return numero; }
    public void setNumero(Integer numero) { this.numero = numero; }
    
    public String getPlaca() { return placa; }
    public void setPlaca(String placa) { this.placa = placa; }
    
    public String getFabricante() { return fabricante; }
    public void setFabricante(String fabricante) { this.fabricante = fabricante; }
    
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }
    
    public Integer getAnoModelo() { return anoModelo; }
    public void setAnoModelo(Integer anoModelo) { this.anoModelo = anoModelo; }
    
    public Integer getQtdPortas() { return qtdPortas; }
    public void setQtdPortas(Integer qtdPortas) { this.qtdPortas = qtdPortas; }
    
    public String getAcessorios() { return acessorios; }
    public void setAcessorios(String acessorios) { this.acessorios = acessorios; }
    
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }
    
    public Date getDataCadastro() { return dataCadastro; }
    public void setDataCadastro(Date dataCadastro) { this.dataCadastro = dataCadastro; }
    
    public String getDescricaoCompleta() {
        return fabricante + " " + modelo + " (" + anoModelo + ") - " + placa;
    }
}